import { Injectable, NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateStudentDto } from './dto/create-student.dto';
import { UpdateStudentDto } from './dto/update-student.dto';
import { Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';
import * as XLSX from 'xlsx';
import 'multer';

@Injectable()
export class StudentsService {
    constructor(private prisma: PrismaService) { }

    async create(dto: CreateStudentDto) {
        // 1. เช็คว่ามีผู้ใช้นี้อยู่แล้วหรือไม่
        const existing = await this.prisma.user.findUnique({ where: { citizenId: dto.citizenId } });
        if (existing) throw new ConflictException('รหัสนักเรียนนี้มีในระบบแล้ว');

        // 2. Hash Password
        const hashedPassword = await bcrypt.hash(dto.password, 10);

        // 3. สร้าง User โดยระบุ Role เป็น STUDENT
        return this.prisma.user.create({
            data: {
                ...dto,
                password: hashedPassword,
                role: Role.STUDENT,
            },
            select: { id: true, citizenId: true, firstName: true, lastName: true, classroom: true }
        });
    }

    async findAll(classroomId?: number) {
        return this.prisma.user.findMany({
            where: {
                role: Role.STUDENT,
                ...(classroomId && { classroomId }), // ถ้าส่ง classroomId มาให้กรองตามห้อง
            },
            include: { classroom: true },
        });
    }

    async findOne(id: string) {
        const student = await this.prisma.user.findFirst({
            where: { id, role: Role.STUDENT },
            include: { classroom: true },
        });
        if (!student) throw new NotFoundException('ไม่พบข้อมูลนักเรียน');
        return student;
    }

    async update(id: string, dto: UpdateStudentDto) {
        await this.findOne(id);

        const data = { ...dto };
        if (dto.password) {
            data.password = await bcrypt.hash(dto.password, 10);
        }

        return this.prisma.user.update({
            where: { id },
            data,
        });
    }

    async remove(id: string) {
        await this.findOne(id);
        return this.prisma.user.delete({ where: { id } });
    }

     async importStudents(file: Express.Multer.File) {
    if (!file) throw new BadRequestException('กรุณาอัปโหลดไฟล์ Excel');

    // 1. อ่านไฟล์จาก Buffer
    const workbook = XLSX.read(file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    
    // 2. แปลงข้อมูลใน Sheet เป็น JSON
    // คาดหวัง Header ใน Excel: citizenId, firstName, lastName, password, classroomId
    const rows = XLSX.utils.sheet_to_json(sheet) as any[];

    const results = {
      success: 0,
      errors: [] as string[],
    };

    // 3. วนลูปบันทึกข้อมูล (ใช้ Loop เพื่อจัดการ Error รายคนได้ละเอียดกว่า)
    for (const row of rows) {
      try {
        // ตรวจสอบข้อมูลเบื้องต้น
        if (!row.citizenId || !row.classroomId) {
          results.errors.push(`แถวที่ชื่อ ${row.firstName}: ข้อมูลไม่ครบถ้วน`);
          continue;
        }

        // เข้ารหัสผ่าน (ถ้าไม่มีในไฟล์ ให้ใช้เลขท้ายบัตรประชาชนหรือค่า Default)
        const password = row.password ? String(row.password) : '123456';
        const hashedPassword = await bcrypt.hash(password, 10);

        await this.prisma.user.create({
          data: {
            citizenId: String(row.citizenId),
            firstName: row.firstName,
            lastName: row.lastName,
            password: hashedPassword,
            role: Role.STUDENT,
            classroomId: Number(row.classroomId),
          },
        });
        results.success++;
      } catch (error: any) {
        results.errors.push(`รหัส ${row.citizenId}: ${error.message}`);
      }
    }

    return {
      message: 'ดำเนินการนำเข้าข้อมูลเสร็จสิ้น',
      ...results,
    };
  }
}