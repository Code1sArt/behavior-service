export class Holiday {}
